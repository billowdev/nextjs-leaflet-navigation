"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 3866:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_ModalList)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "@material-ui/core/styles"
const styles_namespaceObject = require("@material-ui/core/styles");
// EXTERNAL MODULE: external "@material-ui/core"
var core_ = __webpack_require__(8130);
;// CONCATENATED MODULE: ./components/ModalList.tsx




const useStyles = (0,styles_namespaceObject.makeStyles)((theme)=>({
        modal: {
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
        },
        paper: {
            backgroundColor: theme.palette.background.paper,
            borderRadius: "4px",
            boxShadow: theme.shadows[5],
            padding: theme.spacing(2, 4, 3)
        }
    }));
function ModalList({ open , onClose , nodes , onSelect  }) {
    const classes = useStyles();
    const handleListItemClick = (node)=>{
        onSelect(node);
        onClose();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(core_.Modal, {
        className: classes.modal,
        open: open,
        onClose: onClose,
        closeAfterTransition: true,
        BackdropComponent: core_.Backdrop,
        BackdropProps: {
            timeout: 500
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(core_.Fade, {
            in: open,
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: classes.paper,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: "เลือกปลายทาง"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(core_.List, {
                        component: "nav",
                        children: nodes.map((node, index)=>/*#__PURE__*/ jsx_runtime_.jsx(core_.ListItem, {
                                button: true,
                                onClick: ()=>handleListItemClick(node.bid),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(core_.ListItemText, {
                                    primary: node.name
                                })
                            }, index))
                    })
                ]
            })
        })
    });
}
/* harmony default export */ const components_ModalList = (ModalList);


/***/ }),

/***/ 2603:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getStaticProps": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _services_navigationService__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4867);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8130);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ModalList__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3866);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _utils_constant_util__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6542);
/* harmony import */ var _components_Footer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(932);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_MyLocation__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5924);
/* harmony import */ var _mui_icons_material_MyLocation__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MyLocation__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_Navigation__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(9607);
/* harmony import */ var _mui_icons_material_Navigation__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Navigation__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_icons_material_Place__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5214);
/* harmony import */ var _mui_icons_material_Place__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Place__WEBPACK_IMPORTED_MODULE_13__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_navigationService__WEBPACK_IMPORTED_MODULE_3__]);
_services_navigationService__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
















const MapContainer = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "index.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const TileLayer = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "index.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const Marker = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "index.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
const Popup = next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
    loadableGenerated: {
        modules: [
            "index.tsx -> " + "react-leaflet"
        ]
    },
    ssr: false
});
function Navigation({ nodes , buildings  }) {
    const center = [
        17.188552015996446,
        104.08972433221602
    ]; // Centered on Sakon Nakhon Province
    const zoom = 16;
    const bounds = [
        [
            17.18355011514967,
            104.08249309701569
        ],
        [
            17.19193437239573,
            104.09560373412965
        ] // Northeast corner of Sakon Nakhon Province
    ];
    const [modalOpen, setModalOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedNode, setSelectedNode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const handleModalOpen = ()=>{
        setModalOpen(true);
    };
    const handleModalClose = ()=>{
        setModalOpen(false);
    };
    const handleNodeSelect = (node)=>{
        setSelectedNode(node);
        setModalOpen(false);
    };
    const [payload, setPayload] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        best_path: [],
        coordinates: [],
        distance: 0,
        from_start: "",
        navigation: [],
        to_goal: ""
    });
    const handleFetchData = async ()=>{
        if (selectedNode) {
            const response = await _services_navigationService__WEBPACK_IMPORTED_MODULE_3__/* .getNavigation */ .Ti({
                start: currentPosition,
                goal: selectedNode
            });
            setPayload(response.payload);
        }
    };
    const [currentPosition, setCurrentPosition] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        17.189578289590823,
        104.090411954494540
    ]); // initialize with dummy values
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const intervalId = setInterval(()=>{
            navigator.geolocation.getCurrentPosition((position)=>setCurrentPosition([
                    position.coords.latitude,
                    position.coords.longitude
                ]), (error)=>console.log(error));
        }, 3000);
        return ()=>clearInterval(intervalId);
    }, []);
    const hadnleCurrentLocation = async ()=>{
        navigator.geolocation.getCurrentPosition((position)=>setCurrentPosition([
                position.coords.latitude,
                position.coords.longitude
            ]), (error)=>console.log(error));
    };
    const Map = react__WEBPACK_IMPORTED_MODULE_1___default().useMemo(()=>next_dynamic__WEBPACK_IMPORTED_MODULE_2___default()(null, {
            loadableGenerated: {
                modules: [
                    "index.tsx -> " + "../components/MapComponent"
                ]
            },
            loading: ()=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: "A map is loading"
                }),
            ssr: false // This line is important. It's what prevents server-side render
        }), []);
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_10__.useTheme)();
    const isSmallerScreen = (0,_mui_material__WEBPACK_IMPORTED_MODULE_9__.useMediaQuery)(theme.breakpoints.down("sm"));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Box, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Container, {
                style: {
                    marginTop: "20px"
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                        container: true,
                        style: {
                            marginBottom: "20px",
                            justifyContent: "center"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                item: true,
                                style: {
                                    margin: isSmallerScreen ? "10px 0" : "0 10px"
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                    variant: "contained",
                                    color: "primary",
                                    onClick: hadnleCurrentLocation,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_MyLocation__WEBPACK_IMPORTED_MODULE_11___default()), {}),
                                        " ตำแหน่งปัจจุบัน"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                item: true,
                                style: {
                                    margin: isSmallerScreen ? "10px 0" : "0 10px"
                                },
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                        variant: "contained",
                                        color: "primary",
                                        onClick: handleModalOpen,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Place__WEBPACK_IMPORTED_MODULE_13___default()), {}),
                                            " เลือกปลายทาง"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ModalList__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        open: modalOpen,
                                        onClose: handleModalClose,
                                        onSelect: handleNodeSelect,
                                        nodes: buildings
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                item: true,
                                style: {
                                    margin: isSmallerScreen ? "10px 0" : "0 10px"
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                    variant: "contained",
                                    color: "primary",
                                    onClick: handleFetchData,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Navigation__WEBPACK_IMPORTED_MODULE_12___default()), {}),
                                        " เริ่มต้นนำทาง"
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Box, {
                        marginBottom: 1,
                        children: selectedNode && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                    variant: "h5",
                                    gutterBottom: true,
                                    children: "ปลายทาง"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Box, {
                                    marginTop: 1,
                                    children: buildings.filter(({ bid  })=>bid === selectedNode).map((building)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_9__.Box, {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    children: [
                                                        " Building ID: ",
                                                        building.bid
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_material_ui_core__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    children: [
                                                        " Name: ",
                                                        building.name
                                                    ]
                                                })
                                            ]
                                        }, building.id))
                                })
                            ]
                        })
                    }),
                    payload.best_path.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Map, {
                        bestPath: payload.best_path,
                        coordinates: payload.coordinates,
                        navigation: payload.navigation
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(MapContainer, {
                        center: center,
                        zoom: zoom,
                        bounds: bounds,
                        scrollWheelZoom: true,
                        style: {
                            height: "100vh",
                            width: "100%",
                            marginBottom: "20px"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TileLayer, {
                                url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Marker, {
                                position: currentPosition,
                                autoPanOnFocus: true,
                                autoPan: true,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Popup, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                            children: "ตำแหน่งปัจจุบันของคุณ"
                                        })
                                    })
                                })
                            }),
                            buildings.map(({ bid , name , desc , lat , lng , image  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Marker, {
                                    position: [
                                        parseFloat(lat),
                                        parseFloat(lng)
                                    ],
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Popup, {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                    children: bid
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                    children: name
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: desc
                                                }),
                                                image ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                                        src: `${_utils_constant_util__WEBPACK_IMPORTED_MODULE_7__/* .BUILDING_IMAGE_ROUTE */ .cL}/${image}`,
                                                        alt: "My Image",
                                                        width: 100,
                                                        height: 100
                                                    })
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {})
                                            ]
                                        })
                                    })
                                }, bid))
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Footer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
        ]
    });
}
const getStaticProps = async ()=>{
    const nodeResponse = await _services_navigationService__WEBPACK_IMPORTED_MODULE_3__/* .getNode */ .Mk();
    const buildingsResponse = await _services_navigationService__WEBPACK_IMPORTED_MODULE_3__/* .getBuildings */ .x9();
    const nodes = nodeResponse.payload[0];
    const buildings = buildingsResponse.payload;
    return {
        props: {
            nodes,
            buildings
        }
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Navigation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8130:
/***/ ((module) => {

module.exports = require("@material-ui/core");

/***/ }),

/***/ 5924:
/***/ ((module) => {

module.exports = require("@mui/icons-material/MyLocation");

/***/ }),

/***/ 9607:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Navigation");

/***/ }),

/***/ 5214:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Place");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 8442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 2591:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 5832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [636,675,152,867,932], () => (__webpack_exec__(2603)));
module.exports = __webpack_exports__;

})();