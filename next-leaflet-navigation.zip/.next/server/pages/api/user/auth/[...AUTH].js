"use strict";
(() => {
var exports = {};
exports.id = 427;
exports.ids = [427];
exports.modules = {

/***/ 4802:
/***/ ((module) => {

module.exports = require("cookie");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 2369:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _utils_constant_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2045);
/* harmony import */ var _utils_cookies_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1072);
/* harmony import */ var _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6516);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__]);
_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction




function handler(req, res) {
    if (req.query.AUTH) {
        const action = req.query["AUTH"][0];
        if (req.method === _utils_constant_util__WEBPACK_IMPORTED_MODULE_0__/* .HTTP_METHOD_POST */ .CK && action === "signin") {
            return signin(req, res);
        } else if (req.method === _utils_constant_util__WEBPACK_IMPORTED_MODULE_0__/* .HTTP_METHOD_GET */ .$h && action === "signout") {
            return signout(req, res);
        } else if (req.method === _utils_constant_util__WEBPACK_IMPORTED_MODULE_0__/* .HTTP_METHOD_GET */ .$h && action === "session") {
            return getSession(req, res);
        } else {
            return res.status(405).end(`Error: HTTP ${req.method} is not supported for ${req.url}`);
        }
    }
}
async function signin(req, res) {
    try {
        const { username , password  } = req.body;
        const response = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__/* ["default"].post */ .Z.post(`/users/login`, {
            username,
            password
        });
        const { access_token  } = response.data.user;
        (0,_utils_cookies_util__WEBPACK_IMPORTED_MODULE_1__/* .setCookie */ .d)(res, _utils_constant_util__WEBPACK_IMPORTED_MODULE_0__/* .ACCESS_TOKEN_KEY */ .Wx, access_token, {
            httpOnly: true,
            // secure: process.env.NODE_ENV !== "development",
            sameSite: "strict",
            path: "/"
        });
        res.json(response.data);
    } catch (error) {
        res.status(400).end();
    }
}
const signout = async (req, res)=>{
    (0,_utils_cookies_util__WEBPACK_IMPORTED_MODULE_1__/* .clearCookie */ ._)(res, _utils_constant_util__WEBPACK_IMPORTED_MODULE_0__/* .ACCESS_TOKEN_KEY */ .Wx);
    res.json({
        result: "signout successfuly"
    });
};
const getSession = async (req, res)=>{
    try {
        const cookies = cookie__WEBPACK_IMPORTED_MODULE_3___default().parse(req.headers.cookie || "");
        const token = cookies[_utils_constant_util__WEBPACK_IMPORTED_MODULE_0__/* .ACCESS_TOKEN_KEY */ .Wx];
        if (token) {
            const response = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get(`/users/getsession`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            res.status(200).json(response.data);
        } else {
            res.status(400).json({
                success: false,
                msg: "token not found"
            });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            msg: "something wentwrong"
        });
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2045:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$h": () => (/* binding */ HTTP_METHOD_GET),
/* harmony export */   "CK": () => (/* binding */ HTTP_METHOD_POST),
/* harmony export */   "L": () => (/* binding */ HTTP_METHOD_DELETE),
/* harmony export */   "Wx": () => (/* binding */ ACCESS_TOKEN_KEY),
/* harmony export */   "Z": () => (/* binding */ HTTP_METHOD_PATCH)
/* harmony export */ });
/* unused harmony exports DISPLAY_MODE_TEXT, BUILDING_IMAGE_ROUTE, ENDPOINT, NEXT_PUBLIC_IMAGE_HOST */
const DISPLAY_MODE_TEXT = "TEXT";
const HTTP_METHOD_GET = "GET";
const HTTP_METHOD_POST = "POST";
const HTTP_METHOD_DELETE = "DELETE";
const HTTP_METHOD_PATCH = "PATCH";
const ACCESS_TOKEN_KEY = "access_token";
const BUILDING_IMAGE_ROUTE = (/* unused pure expression or super */ null && ("https://snru.billowdev.com/services/buildings/images"));
const ENDPOINT = (/* unused pure expression or super */ null && ("https://snru.billowdev.com/services/api/v1"));
const NEXT_PUBLIC_IMAGE_HOST = (/* unused pure expression or super */ null && ("snru.billowdev.com"));


/***/ }),

/***/ 1072:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ clearCookie),
/* harmony export */   "d": () => (/* binding */ setCookie)
/* harmony export */ });
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4802);
/* harmony import */ var cookie__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(cookie__WEBPACK_IMPORTED_MODULE_0__);

/**
 * This sets `cookie` using the `res` object
 */ const setCookie = (res, name, value, options = {})=>{
    const stringValue = typeof value === "object" ? "j:" + JSON.stringify(value) : String(value);
    if (options.maxAge) {
        options.expires = new Date(Date.now() + options.maxAge);
        options.maxAge = options.maxAge / 1000;
    }
    res.setHeader("Set-Cookie", (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)(name, String(stringValue), options));
};
const clearCookie = (res, name, path = "/")=>{
    res.setHeader("Set-Cookie", (0,cookie__WEBPACK_IMPORTED_MODULE_0__.serialize)(name, "", {
        maxAge: 0,
        path
    }));
};


/***/ }),

/***/ 6516:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const httpClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "https://snru.billowdev.com/services/api/v1"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (httpClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2369));
module.exports = __webpack_exports__;

})();