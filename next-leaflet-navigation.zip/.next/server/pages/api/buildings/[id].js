"use strict";
(() => {
var exports = {};
exports.id = 326;
exports.ids = [326];
exports.modules = {

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 7036:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ handler)
/* harmony export */ });
/* harmony import */ var _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6516);
/* harmony import */ var _utils_constant_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2045);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


async function handler(req, res) {
    if (req.method === _utils_constant_util__WEBPACK_IMPORTED_MODULE_1__/* .HTTP_METHOD_DELETE */ .L) {
        return deleteBuilding(req, res);
    } else if (req.method === _utils_constant_util__WEBPACK_IMPORTED_MODULE_1__/* .HTTP_METHOD_PATCH */ .Z) {
        return updateBuilding(req, res);
    } else {
        return res.status(405).end(`Error: HTTP ${req.method} is not supported for ${req.url}`);
    }
}
async function deleteBuilding(req, res) {
    try {
        const accessToken = req.cookies[_utils_constant_util__WEBPACK_IMPORTED_MODULE_1__/* .ACCESS_TOKEN_KEY */ .Wx];
        if (!accessToken) {
            return res.status(401).json({
                message: "Unauthorized"
            });
        }
        if (req.query) {
            const { data  } = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/buildings/delete/${req.query["id"]}`, {
                headers: {
                    "Authorization": `Bearer ${accessToken}`
                }
            });
            if (data) {
                return res.status(200).json(data);
            } else {
                return res.status(400).json(data);
            }
        } else {
            return res.status(400).json({
                message: "id required"
            });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal Server Error"
        });
    }
}
async function updateBuilding(req, res) {
    try {
        const accessToken = req.cookies[_utils_constant_util__WEBPACK_IMPORTED_MODULE_1__/* .ACCESS_TOKEN_KEY */ .Wx];
        if (!accessToken) {
            return res.status(401).json({
                message: "Unauthorized"
            });
        }
        const updateBody = req.body;
        // console.log(updateBody.file);
        console.log("============ service==============");
        console.log(updateBody);
        console.log("============ service==============");
        if (req.query) {
            const { data  } = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].patch */ .Z.patch(`/buildings/update/${req.query["id"]}`, updateBody, {
                headers: {
                    "Authorization": `Bearer ${accessToken}`
                }
            });
            if (data) {
                return res.status(200).json(data);
            } else {
                return res.status(400).json(data);
            }
        } else {
            return res.status(400).json({
                message: "id required"
            });
        }
    } catch (error) {
        console.error(error);
        return res.status(500).json({
            message: "Internal Server Error"
        });
    }
} // async function createBuilding(req: NextApiRequest, res: NextApiResponse<any>) {
 //   try {
 //     const accessToken = req.cookies[ACCESS_TOKEN_KEY];
 //     if (!accessToken) {
 //       return res.status(401).json({ message: 'Unauthorized' });
 //     }
 //     const createBody = req.body;
 //     if (createBody) {
 //       const { data } = await httpClient.post(`/buildings/create`, createBody, {
 //         headers: {
 //           'Authorization': `Bearer ${accessToken}`,
 //         },
 //       });
 //       if(data){
 //         return res.status(200).json(data);
 //       }else{
 //         return res.status(400).json(data);
 //       }
 //     } else {
 //       return res.status(400).json({ message: 'create building is failed' });
 //     }
 //   } catch (error) {
 //     console.error(error);
 //     return res.status(500).json({ message: 'Internal Server Error' });
 //   }
 // }

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2045:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$h": () => (/* binding */ HTTP_METHOD_GET),
/* harmony export */   "CK": () => (/* binding */ HTTP_METHOD_POST),
/* harmony export */   "L": () => (/* binding */ HTTP_METHOD_DELETE),
/* harmony export */   "Wx": () => (/* binding */ ACCESS_TOKEN_KEY),
/* harmony export */   "Z": () => (/* binding */ HTTP_METHOD_PATCH)
/* harmony export */ });
/* unused harmony exports DISPLAY_MODE_TEXT, BUILDING_IMAGE_ROUTE, ENDPOINT, NEXT_PUBLIC_IMAGE_HOST */
const DISPLAY_MODE_TEXT = "TEXT";
const HTTP_METHOD_GET = "GET";
const HTTP_METHOD_POST = "POST";
const HTTP_METHOD_DELETE = "DELETE";
const HTTP_METHOD_PATCH = "PATCH";
const ACCESS_TOKEN_KEY = "access_token";
const BUILDING_IMAGE_ROUTE = (/* unused pure expression or super */ null && ("https://snru.billowdev.com/services/buildings/images"));
const ENDPOINT = (/* unused pure expression or super */ null && ("https://snru.billowdev.com/services/api/v1"));
const NEXT_PUBLIC_IMAGE_HOST = (/* unused pure expression or super */ null && ("snru.billowdev.com"));


/***/ }),

/***/ 6516:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const httpClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "https://snru.billowdev.com/services/api/v1"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (httpClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7036));
module.exports = __webpack_exports__;

})();