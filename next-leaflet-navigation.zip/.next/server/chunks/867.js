"use strict";
exports.id = 867;
exports.ids = [867];
exports.modules = {

/***/ 4867:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Mk": () => (/* binding */ getNode),
/* harmony export */   "Ti": () => (/* binding */ getNavigation),
/* harmony export */   "x9": () => (/* binding */ getBuildings)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5837);
/* harmony import */ var _utils_constant_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6542);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__, _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__]);
([axios__WEBPACK_IMPORTED_MODULE_0__, _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const getNavigation = async (data)=>{
    const start_state = data.start;
    const goal_state = data.goal;
    const body = {
        payload: {
            start_state,
            goal_state
        }
    };
    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(`${_utils_constant_util__WEBPACK_IMPORTED_MODULE_2__/* .ENDPOINT */ .f4}/buildings/navigate/geo`, body, {
        headers: {
            "Content-Type": "application/json"
        },
        method: "POST"
    });
    return response.data;
};
const getBuildings = async ()=>{
    // const response = await axios.get(
    // 	'http://localhost:5000/api/v1/buildings/get'
    //   );
    const { data: response  } = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`/buildings/get/all/node`, {
        baseURL: "https://snru.billowdev.com/services/api/v1"
    });
    return response;
};
const getNode = async ()=>{
    const { data: response  } = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`/buildings/node`, {
        baseURL: "https://snru.billowdev.com/services/api/v1"
    });
    // const response = await axios.get(
    // 	'http://localhost:3000/api/navigation'
    // );
    return response;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6542:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "cL": () => (/* binding */ BUILDING_IMAGE_ROUTE),
/* harmony export */   "f4": () => (/* binding */ ENDPOINT)
/* harmony export */ });
/* unused harmony exports DISPLAY_MODE_TEXT, HTTP_METHOD_GET, HTTP_METHOD_POST, HTTP_METHOD_DELETE, HTTP_METHOD_PATCH, ACCESS_TOKEN_KEY, NEXT_PUBLIC_IMAGE_HOST */
const DISPLAY_MODE_TEXT = "TEXT";
const HTTP_METHOD_GET = "GET";
const HTTP_METHOD_POST = "POST";
const HTTP_METHOD_DELETE = "DELETE";
const HTTP_METHOD_PATCH = "PATCH";
const ACCESS_TOKEN_KEY = "access_token";
const BUILDING_IMAGE_ROUTE = "https://snru.billowdev.com/services/buildings/images";
const ENDPOINT = "https://snru.billowdev.com/services/api/v1";
const NEXT_PUBLIC_IMAGE_HOST = (/* unused pure expression or super */ null && ("snru.billowdev.com"));


/***/ }),

/***/ 5837:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const httpClient = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: "https://snru.billowdev.com/services/api/v1"
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (httpClient);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;