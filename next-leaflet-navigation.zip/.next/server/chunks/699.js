"use strict";
exports.id = 699;
exports.ids = [699];
exports.modules = {

/***/ 7706:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gg": () => (/* binding */ getSession),
/* harmony export */   "w7": () => (/* binding */ signOut),
/* harmony export */   "zB": () => (/* binding */ signIn)
/* harmony export */ });
/* harmony import */ var _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5837);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__]);
_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const signIn = async (user)=>{
    const { data: response  } = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post(`/user/auth/signin`, user, {
        baseURL: "https://snru.billowdev.com/api"
    });
    return response;
};
async function signOut() {
    const response = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/user/auth/signout`, {
        baseURL: "https://snru.billowdev.com/api"
    });
    return response.data;
}
const getSession = async ()=>{
    const response = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/user/auth/session`, {
        baseURL: "https://snru.billowdev.com/api"
    });
    return response.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7825:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fn": () => (/* binding */ updateBuilding),
/* harmony export */   "I0": () => (/* binding */ createBuilding),
/* harmony export */   "Pt": () => (/* binding */ deleteBuilding),
/* harmony export */   "Vm": () => (/* binding */ getBuilding),
/* harmony export */   "x9": () => (/* binding */ getBuildings)
/* harmony export */ });
/* harmony import */ var _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5837);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__]);
([_utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__, axios__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const getBuildings = async ()=>{
    const response = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/buildings/get/all`);
    return response.data.payload;
};
const getBuilding = async (id)=>{
    const { data: response  } = await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/buildings/get/${id}`);
    return response.payload;
};
const createBuilding = async (data, accessToken)=>{
    await axios__WEBPACK_IMPORTED_MODULE_1__["default"].post(`/buildings/create`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://snru.billowdev.com/services/api/v1"
    });
};
const updateBuilding = async (id, data, accessToken)=>{
    await axios__WEBPACK_IMPORTED_MODULE_1__["default"].patch(`/buildings/update/${id}`, data, {
        headers: {
            Authorization: `Bearer ${accessToken}`
        },
        baseURL: "https://snru.billowdev.com/services/api/v1"
    });
};
const deleteBuilding = async (id)=>{
    await _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_0__/* ["default"]["delete"] */ .Z["delete"](`/buildings/${id}`, {
        baseURL: "https://snru.billowdev.com/api"
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6651:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Fn": () => (/* binding */ updateBuilding),
/* harmony export */   "I0": () => (/* binding */ createBuilding),
/* harmony export */   "Pt": () => (/* binding */ deleteBuilding),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "dN": () => (/* binding */ buildingSelector),
/* harmony export */   "x9": () => (/* binding */ getBuildings)
/* harmony export */ });
/* unused harmony export getBuilding */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _store_store__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4897);
/* harmony import */ var _services_buildingService__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7825);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_store_store__WEBPACK_IMPORTED_MODULE_1__, _services_buildingService__WEBPACK_IMPORTED_MODULE_2__]);
([_store_store__WEBPACK_IMPORTED_MODULE_1__, _services_buildingService__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const initialState = {
    buildings: []
};
const getBuilding = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buildings/getById", async (id)=>{
    return await _services_buildingService__WEBPACK_IMPORTED_MODULE_2__/* .getBuilding */ .Vm(id);
});
const getBuildings = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buildings/get", async ()=>{
    return await _services_buildingService__WEBPACK_IMPORTED_MODULE_2__/* .getBuildings */ .x9();
});
const createBuilding = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buildings/create", async (data)=>{
    await _services_buildingService__WEBPACK_IMPORTED_MODULE_2__/* .createBuilding */ .I0(data.data, data.accessToken);
    _store_store__WEBPACK_IMPORTED_MODULE_1__/* .store.dispatch */ .h.dispatch(getBuildings());
});
const updateBuilding = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buildings/update", async (data)=>{
    await _services_buildingService__WEBPACK_IMPORTED_MODULE_2__/* .updateBuilding */ .Fn(data.id, data.body, data.accessToken);
});
const deleteBuilding = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buildings/delete", async (id)=>{
    await _services_buildingService__WEBPACK_IMPORTED_MODULE_2__/* .deleteBuilding */ .Pt(id);
    _store_store__WEBPACK_IMPORTED_MODULE_1__/* .store.dispatch */ .h.dispatch(getBuildings());
});
const buildingSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "building",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(getBuildings.fulfilled, (state, action)=>{
            state.buildings = action.payload;
        });
        builder.addCase(getBuilding.fulfilled, (state, action)=>{
            state.buildings = action.payload;
        });
    }
});
const buildingSelector = (store)=>store.building.buildings;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (buildingSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3918:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports getNavigation, navigationSelector, navigationDataSelector, coordinatesSelector */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_navigationService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4867);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_navigationService__WEBPACK_IMPORTED_MODULE_1__]);
_services_navigationService__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// best_path: ["G1",
// 			"G1L01",],
// 			coordinates: [[
// 				17.19256404202556,
// 				104.09360793646384
// 			],
// 			[
// 				17.192329942043273,
// 				104.09348628794305
// 			],],
// 	distance: 1.3155167600975681,
// 	from_start: "G1",
// 	navigation: [
// 		{
// 			"bid": "G1",
// 			"is_node": true,
// 			"lat": "17.192564042025560",
// 			"lng": "104.093607936463840"
// 		},
// 		{
// 			"bid": "G1L01",
// 			"is_node": false,
// 			"lat": "17.192329942043273",
// 			"lng": "104.093486287943050"
// 		}
// 	],
// 	to_goal: "G1L01",
// 	navigations: {
// 		best_path: ["G1",
// 			"G1L01",],
// 		coordinates: [[
// 			17.19256404202556,
// 			104.09360793646384
// 		],
// 		[
// 			17.192329942043273,
// 			104.09348628794305
// 		],],
// 		distance: 1.3155167600975681,
// 		from_start: "G1",
// 		navigation: [
// 			{
// 				"bid": "G1",
// 				"is_node": true,
// 				"lat": "17.192564042025560",
// 				"lng": "104.093607936463840"
// 			},
// 			{
// 				"bid": "G1L01",
// 				"is_node": false,
// 				"lat": "17.192329942043273",
// 				"lng": "104.093486287943050"
// 			}
// 		],
// 		to_goal: "G1L1",
// 	},
// 	loading: false,
const initialValues = {
    best_path: [],
    coordinates: [],
    distance: 0,
    from_start: "",
    navigation: [],
    to_goal: "",
    navigations: {
        best_path: [],
        coordinates: [],
        distance: 0,
        from_start: "",
        navigation: [],
        to_goal: ""
    },
    loading: false
};
const getNavigation = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("navigation/getNavigation", async (data)=>{
    const { payload: response  } = await _services_navigationService__WEBPACK_IMPORTED_MODULE_1__/* .getNavigation */ .Ti(data);
    return response;
});
const navigationSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "navigation",
    initialState: initialValues,
    reducers: {
    },
    extraReducers: (builder)=>{
        builder.addCase(getNavigation.fulfilled, (state, action)=>{
            state.navigations = action.payload;
            state.best_path = action.payload.best_path;
            state.distance = action.payload.distance;
            state.navigation = action.payload.navigation;
            state.from_start = action.payload.from_start;
            state.to_goal = action.payload.to_goal;
            state.coordinates = action.payload.coordinates;
            state.loading = false;
        });
        builder.addCase(getNavigation.rejected, (state, action)=>{
            state.best_path = [];
            state.coordinates = [];
            state.distance = 0;
            state.from_start = "";
            state.to_goal = "";
            state.loading = false;
        });
    }
});
// export const { test_reducer } = navigationSlice.actions;
// export const navigationSelector = (store: RootState) => store.navigationReducer;
const navigationSelector = (store)=>store.navigation.navigations;
const navigationDataSelector = (store)=>store.navigation.navigation;
const coordinatesSelector = (store)=>store.navigation.coordinates;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (navigationSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1121:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Gg": () => (/* binding */ getSession),
/* harmony export */   "Gq": () => (/* binding */ isAuthenticatedSelector),
/* harmony export */   "TP": () => (/* binding */ isAuthenticatingSelector),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "np": () => (/* binding */ userSelector),
/* harmony export */   "w7": () => (/* binding */ signOut),
/* harmony export */   "zB": () => (/* binding */ signIn)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _services_authService__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7706);
/* harmony import */ var _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5837);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_services_authService__WEBPACK_IMPORTED_MODULE_1__, _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__]);
([_services_authService__WEBPACK_IMPORTED_MODULE_1__, _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const initialState = {
    accessToken: "",
    isAuthenticated: false,
    isAuthenticating: true,
    user: undefined
};
const signIn = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("user/signin", async (credential)=>{
    const response = await _services_authService__WEBPACK_IMPORTED_MODULE_1__/* .signIn */ .zB(credential);
    if (response.user == null) {
        throw new Error("login failed");
    }
    _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__/* ["default"].interceptors.request.use */ .Z.interceptors.request.use((config)=>{
        if (config && config.headers) {
            config.headers["Authorization"] = `Bearer ${response.token}`;
        }
        return config;
    });
    return response;
});
const signOut = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("user/signout", async ()=>{
    await _services_authService__WEBPACK_IMPORTED_MODULE_1__/* .signOut */ .w7();
    next_router__WEBPACK_IMPORTED_MODULE_3___default().push("/panel/login");
});
const getSession = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("user/fetchSession", async ()=>{
    const response = await _services_authService__WEBPACK_IMPORTED_MODULE_1__/* .getSession */ .Gg();
    // set access token
    if (response) {
        _utils_httpClient_util__WEBPACK_IMPORTED_MODULE_2__/* ["default"].interceptors.request.use */ .Z.interceptors.request.use((config)=>{
            if (config && config.headers) {
                config.headers["Authorization"] = `Bearer ${response.access_token}`;
            }
            return config;
        });
    }
    return response;
});
const userSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "user",
    initialState: initialState,
    reducers: {},
    extraReducers: (builder)=>{
        builder.addCase(signIn.fulfilled, (state, action)=>{
            state.isAuthenticated = true;
            state.isAuthenticating = false;
            state.user = action.payload.user;
        });
        builder.addCase(signIn.rejected, (state, action)=>{
            state.isAuthenticated = false;
            state.isAuthenticating = false;
            state.user = undefined;
        });
        builder.addCase(signOut.fulfilled, (state, action)=>{
            state.accessToken = "";
            state.isAuthenticated = false;
            state.isAuthenticating = false;
            state.user = undefined;
        });
        builder.addCase(getSession.fulfilled, (state, action)=>{
            state.isAuthenticating = false;
            if (action.payload) {
                state.accessToken = action.payload.access_token;
                state.isAuthenticated = true;
            }
        });
        builder.addCase(getSession.rejected, (state, action)=>{
            state.isAuthenticating = false;
            state.isAuthenticated = false;
            state.accessToken = "";
            state.user = undefined;
        });
    }
});
const userSelector = (store)=>store.user;
const isAuthenticatedSelector = (store)=>store.user.isAuthenticated;
const isAuthenticatingSelector = (store)=>store.user.isAuthenticating;
// // export reducer
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (userSlice.reducer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4897:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ useAppDispatch),
/* harmony export */   "h": () => (/* binding */ store)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _slices_userSlice__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1121);
/* harmony import */ var _slices_buildingSlice__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6651);
/* harmony import */ var _slices_navigationSlice__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3918);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_slices_userSlice__WEBPACK_IMPORTED_MODULE_2__, _slices_buildingSlice__WEBPACK_IMPORTED_MODULE_3__, _slices_navigationSlice__WEBPACK_IMPORTED_MODULE_4__]);
([_slices_userSlice__WEBPACK_IMPORTED_MODULE_2__, _slices_buildingSlice__WEBPACK_IMPORTED_MODULE_3__, _slices_navigationSlice__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const reducer = {
    user: _slices_userSlice__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP,
    navigation: _slices_navigationSlice__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP,
    building: _slices_buildingSlice__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .ZP
};
const store = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.configureStore)({
    reducer,
    // devTools: process.env.NODE_ENV === "development",
    devTools: true
});
const useAppDispatch = ()=>(0,react_redux__WEBPACK_IMPORTED_MODULE_1__.useDispatch)();

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;