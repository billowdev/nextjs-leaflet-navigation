export interface UserData {
	id?: string;
	name?: string;
	surname?: string;
	username?: string;
	password?: string;
	createdAt?: Date;
	updatedAt?: Date;
}